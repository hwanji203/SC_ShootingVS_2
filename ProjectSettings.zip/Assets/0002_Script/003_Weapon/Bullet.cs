using UnityEngine;

public class Bullet : MonoBehaviour
{
    private Rigidbody2D rb;
    public BulletDataSO BulletData { get; set; }

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        rb.linearVelocity = transform.right * BulletData.BulletSpeed;
    }
}
